// グラフの場所
var ctx_0 = document.getElementById("chartjs-0").getContext('2d');
ctx_0.canvas.height = 70;
ctx_0.canvas.width = 100;
var ctx_1 = document.getElementById("chartjs-1").getContext('2d');
ctx_1.canvas.height = 70;
ctx_1.canvas.width = 100;
var ctx_2 = document.getElementById("chartjs-2").getContext('2d');
ctx_2.canvas.height = 70;
ctx_2.canvas.width = 100;
var ctx_3 = document.getElementById("chartjs-3").getContext('2d');
ctx_3.canvas.height = 70;
ctx_3.canvas.width = 100;


// グラフの実体
new Chart(ctx_0,
          {
  "type":"line",
  "data":
  {
    "labels":["2","3","4","5","6","7","8","9","10","11"],
    "datasets":[
      {
        "label":"学習",
        "data":ctx_0_learn_data,
        "fill":false,
        "borderColor":"rgb(192, 75, 75)",
        "lineTension":0
      },
      {
        "label":"評価",
        "data":ctx_0_evaluate_data,
        "fill":false,
        "borderColor":"rgb(75, 192, 192)",
        "lineTension":0
      }
    ]
  },
  "options":{
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'グリッドの幅'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: '条件下における成功率'
        },
        ticks: {
          min: 0
        }
      }]
    }
  }
});

new Chart(ctx_1,
          {
  "type":"line",
  "data":
  {
    "labels":["1", "2","3","4","5","6","7","8","9","10"],
    "datasets":[
      {
        "label":"学習",
        "data":ctx_1_learn_data,
        "fill":false,
        "borderColor":"rgb(192, 75, 75)",
        "lineTension":0
      },
      {
        "label":"評価",
        "data":ctx_1_evaluate_data,
        "fill":false,
        "borderColor":"rgb(75, 192, 192)",
        "lineTension":0
      }
    ]
  },
  "options":{
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'Tの大きさ'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: '条件下における成功率'
        },
        ticks: {
          min: 0
        }
      }]
    }
  }
});

new Chart(ctx_2,
          {
  "type":"line",
  "data":
  {
    "labels":["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"],
    "datasets":[
      {
        "label":"学習",
        "data":ctx_2_learn_data,
        "fill":false,
        "borderColor":"rgb(192, 75, 75)",
        "lineTension":0
      }
    ]
  },
  "options":{
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: 'エージェントの寿命'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: '条件下における成功率'
        },
        ticks: {
          min: 0
        }
      }]
    }
  }
});

new Chart(ctx_3,
          {
  "type":"line",
  "data":
  {
    "labels":["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"],
    "datasets":[
      {
        "label":"学習",
        "data":ctx_3_learn_data,
        "fill":false,
        "borderColor":"rgb(192, 75, 75)",
        "lineTension":0
      }
    ]
  },
  "options":{
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: '学習の繰り返し回数'
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: '条件下における成功率'
        },
        ticks: {
          min: 0
        }
      }]
    }
  }
});
